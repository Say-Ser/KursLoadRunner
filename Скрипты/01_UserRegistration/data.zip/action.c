Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_add_cookie("anj=dTM7k!M4/YD>6NRF']wIg2In@wulXX!]tbPl1Mxx'a(`xU`pu.Sh0)<_eG[sSgt>%a[fn)uUP-5<mcF'9sk@3@'u0e4(v@H6^Q?n; DOMAIN=acdn.adnxs.com");

	web_add_cookie("uuid2=57369608809962286; DOMAIN=acdn.adnxs.com");

	web_add_cookie("icu=ChgIxqEVEAoYASABKAEw9u-T-AU4AUABSAEQ9u-T-AUYAA..; DOMAIN=acdn.adnxs.com");

	web_url("ast.js", 
		"URL=https://acdn.adnxs.com/ast/ast.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=https://www.msn.com/spartan/ientp?locale=ru-RU&market=RU&enableregulatorypsm=0&enablecpsm=0&NTLogo=0&IsFRE=0", 
		"Snapshot=t1.inf", 
		LAST);

	return 0;
}